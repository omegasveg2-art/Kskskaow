#include "code.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>

// ------------------------------------------------------------------ counter
uint64_t counter_now() {
#if defined(__aarch64__)
    uint64_t v;
    asm volatile("mrs %0, cntvct_el0" : "=r"(v));
    return v;
#else
    return (uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
#endif
}
uint64_t counter_freq() {
#if defined(__aarch64__)
    uint64_t v;
    asm volatile("mrs %0, cntfrq_el0" : "=r"(v));
    return v ? v : 19200000ull;
#else
    return 1000000000ull;
#endif
}

void look_quat(Vec3 d, float q[4]) {
    d = norm(d);
    float yaw = std::atan2(d.x, d.z), pit = std::asin(std::max(-1.f, std::min(1.f, d.y)));
    float cy = std::cos(yaw * 0.5f), sy = std::sin(yaw * 0.5f), cx = std::cos(-pit * 0.5f), sx = std::sin(-pit * 0.5f);   // Euler(-pitch, yaw, 0)
    q[0] = cy * sx; q[1] = sy * cx; q[2] = -sy * sx; q[3] = cy * cx;
}

// ------------------------------------------------------------------ CodePatcher
bool CodePatcher::patch(uint64_t addr, const void* bytes, size_t n) {
    std::vector<uint8_t> cur(n);
    if (!m_.read(addr, cur.data(), n)) return false;
    if (!orig_.count(addr)) orig_[addr] = cur;
    if (!m_.write(addr, bytes, n)) return false;
    std::vector<uint8_t> back(n);
    if (!m_.read(addr, back.data(), n) || memcmp(back.data(), bytes, n) != 0) { m_.write(addr, orig_[addr].data(), n); orig_.erase(addr); return false; }
    put_[addr].assign((const uint8_t*)bytes, (const uint8_t*)bytes + n);
    return true;
}

void CodePatcher::restore(uint64_t addr) {
    auto it = orig_.find(addr);
    if (it == orig_.end()) return;
    // write the original back ONLY if the memory still holds our patch: never blind-write into code we no longer own
    std::vector<uint8_t> cur(it->second.size());
    bool rd = m_.read(addr, cur.data(), cur.size());
    auto pu = put_.find(addr);
    bool ours = rd && (pu == put_.end() ? true : cur == pu->second);      // adopted entries (no put_) are restored if they are not already original
    if (ours && cur != it->second) m_.write(addr, it->second.data(), it->second.size());
    orig_.erase(it);
    if (pu != put_.end()) put_.erase(pu);
}

void CodePatcher::restore_all() {
    while (!orig_.empty()) restore(orig_.begin()->first);
}

void CodePatcher::adopt(uint64_t addr, const void* origBytes, size_t n) {
    if (!orig_.count(addr)) orig_[addr] = std::vector<uint8_t>((const uint8_t*)origBytes, (const uint8_t*)origBytes + n);
}

bool CodePatcher::ret_at(uint64_t addr) {
    uint32_t cur = 0;
    if (!m_.read(addr, &cur, 4) || cur == 0) return false;        // unreadable / zero page: not a function
    uint32_t r = a64::RET;
    return patch(addr, &r, 4);
}

// ------------------------------------------------------------------ SilentHook
static int64_t sext(uint64_t v, int bits) { uint64_t m = 1ull << (bits - 1); return (int64_t)((v ^ m) - m); }

bool SilentHook::build(uint64_t c, uint64_t func, uint32_t first, int nf, std::vector<uint8_t>& out, std::string& err) {
    using namespace a64;
    uint32_t w[SIZE / 4] = {0};
    uint32_t origSlot = first;
    uint64_t reloc = 0;
    if ((first & 0x9F000000u) == 0x90000000u || (first & 0x9F000000u) == 0x10000000u) {          // adrp / adr: keep the absolute target in the cave
        uint32_t rd = first & 31, lo = (first >> 29) & 3, hi = (first >> 5) & 0x7FFFF;
        int64_t imm = sext(((uint64_t)hi << 2) | lo, 21);
        reloc = (first & 0x80000000u) ? (uint64_t)((int64_t)(func & ~0xFFFull) + (imm << 12)) : (uint64_t)((int64_t)func + imm);
        origSlot = ldr_x(rd, c + ORIGSLOT, c + RELOC);
    } else if ((first & 0x3B000000u) == 0x18000000u || (first & 0x7C000000u) == 0x14000000u || (first & 0x7E000000u) == 0x34000000u ||
               (first & 0x7E000000u) == 0x36000000u || (first & 0xFF000010u) == 0x54000000u) {
        err = "first instruction is pc-relative (b/bl/ldr lit/cbz): not relocatable";
        return false;
    }
    const uint32_t O = ORIGSLOT;
    w[0x00 / 4] = MRS_X9_CNTVCT;
    w[0x04 / 4] = ldr_x(10, c + 0x04, c + DEADLINE);
    w[0x08 / 4] = CMP_X9_X10;
    w[0x0C / 4] = b_hi(c + 0x0C, c + O);                       // deadline passed -> original path
    w[0x10 / 4] = ldr_w(11, c + 0x10, c + ENABLE);
    w[0x14 / 4] = cbz_w(11, c + 0x14, c + O);                  // disabled -> original path
    w[0x18 / 4] = ldr_s(3, c + 0x18, c + VALS + 0);
    w[0x1C / 4] = ldr_s(4, c + 0x1C, c + VALS + 4);
    w[0x20 / 4] = ldr_s(5, c + 0x20, c + VALS + 8);
    w[0x24 / 4] = nf >= 4 ? ldr_s(6, c + 0x24, c + VALS + 12) : NOP;
    // 0x28..0x34: nops. The cave sits in an r-x page of the game: the game itself must never WRITE there (a store = SIGSEGV on the first shot);
    // only cf_core writes the data words, from outside through /proc/pid/mem.
    w[0x28 / 4] = NOP; w[0x2C / 4] = NOP; w[0x30 / 4] = NOP; w[0x34 / 4] = NOP;
    w[O / 4] = origSlot;                                       // the displaced first instruction
    w[0x3C / 4] = b(c + 0x3C, func + 4);
    memcpy(&w[RELOC / 4], &reloc, 8);
    w[ORIGW / 4] = first;                                      // raw original word: lets a later run restore the function
    out.assign((uint8_t*)w, (uint8_t*)w + SIZE);
    return true;
}

static bool is_cave_image(IMem& m, uint64_t c) {
    uint32_t w[0x70 / 4];
    if (!m.read(c, w, sizeof w)) return false;
    return w[0] == a64::MRS_X9_CNTVCT && w[2] == a64::CMP_X9_X10 && w[0x68 / 4] != 0;
}

static uint64_t find_cave(IMem& m, uint64_t near, std::string& err) {
    const uint32_t need = SilentHook::SIZE + 16;
    std::vector<uint8_t> buf;
    bool any = false;
    auto regs = m.regions();
    for (auto it = regs.rbegin(); it != regs.rend(); ++it) {
        if (!it->r || !it->x || it->path.find("libil2cpp") == std::string::npos) continue;
        any = true;
        for (uint64_t end = it->end; end > it->start;) {
            uint64_t a = end > it->start + (4u << 20) ? end - (4u << 20) : it->start;
            size_t n = (size_t)(end - a);
            buf.resize(n);
            if (m.read(a, buf.data(), n)) {
                size_t run = 0;
                for (size_t i = n; i-- > 0;) {                          // from the end: padding sits at the tail of text
                    run = buf[i] == 0 ? run + 1 : 0;
                    if (run >= need + 16) {
                        uint64_t c = (a + i + 15) & ~15ull;
                        if (c + need <= a + i + run) {
                            int64_t d = (int64_t)c - (int64_t)near;
                            if (d > -0x7000000 && d < 0x7000000) return c;
                        }
                    }
                }
            }
            if (a == it->start) break;
            end = a + 0x200;                                            // overlap so runs on a chunk border are still seen
        }
    }
    err = any ? "no zero padding cave near the function" : "libil2cpp text mapping not found";
    return 0;
}

bool SilentHook::install(uint64_t func, int nf, std::string& err) {
    if (cave_) return true;
    uint32_t first = 0;
    if (!m_.read(func, &first, 4) || first == 0) { err = "function not readable"; return false; }
    // an earlier cf_core run may have left its detour in place: adopt its cave instead of building a second one
    if ((first & 0xFC000000u) == 0x14000000u) {
        uint64_t tgt = func + (uint64_t)(sext(first & 0x03FFFFFF, 26) << 2);
        if (is_cave_image(m_, tgt)) {
            uint32_t ow = 0;
            m_.read(tgt + ORIGW, &ow, 4);
            cp_.adopt(func, &ow, 4);
            cave_ = tgt; func_ = func; nf_ = nf;
            return true;
        }
        err = "function already starts with a branch (foreign patch?)";
        return false;
    }
    uint64_t c = find_cave(m_, func, err);
    if (!c) return false;
    std::vector<uint8_t> img;
    if (!build(c, func, first, nf, img, err)) return false;
    if (!m_.write(c, img.data(), img.size())) { err = "cave write failed"; return false; }
    std::vector<uint8_t> back(img.size());
    if (!m_.read(c, back.data(), back.size()) || memcmp(back.data(), img.data(), img.size()) != 0) { err = "cave read-back mismatch"; return false; }
    uint32_t br = a64::b(func, c);
    if (!cp_.patch(func, &br, 4)) { err = "function patch failed"; return false; }
    cave_ = c; func_ = func; nf_ = nf;
    return true;
}

void SilentHook::feed(const float* v, uint64_t deadline) {
    if (!cave_) return;
    uint8_t blk[0x20] = {0};                                   // 0x40 deadline, 0x48 enable, 0x4C values
    memcpy(blk, &deadline, 8);
    uint32_t en = 1;
    memcpy(blk + 8, &en, 4);
    memcpy(blk + 12, v, 4 * nf_);
    m_.write(cave_ + DEADLINE, blk, sizeof blk);
    enabled_ = true;
}

uint32_t SilentHook::hits() { return 0; }          // no in-cave counter any more (see build()): shots are counted by Game from the weapon state

void SilentHook::off() {
    if (!cave_ || !enabled_) return;
    uint32_t z = 0;
    m_.write(cave_ + ENABLE, &z, 4);
    enabled_ = false;
}

void SilentHook::uninstall() {
    off();
    if (func_) cp_.restore(func_);
    cave_ = 0; func_ = 0;
}

// ------------------------------------------------------------------ RayHook (by-reference aim-vector overwrite)
bool RayHook::build(uint64_t c, uint64_t func, uint32_t first, uint32_t ptrReg, std::vector<uint8_t>& out, std::string& err) {
    using namespace a64;
    uint32_t w[SIZE / 4] = {0};
    uint32_t origSlot = first;
    uint64_t reloc = 0;
    if ((first & 0x9F000000u) == 0x90000000u || (first & 0x9F000000u) == 0x10000000u) {          // adrp / adr: keep the absolute target in the cave
        uint32_t rd = first & 31, lo = (first >> 29) & 3, hi = (first >> 5) & 0x7FFFF;
        int64_t imm = sext(((uint64_t)hi << 2) | lo, 21);
        reloc = (first & 0x80000000u) ? (uint64_t)((int64_t)(func & ~0xFFFull) + (imm << 12)) : (uint64_t)((int64_t)func + imm);
        origSlot = ldr_x(rd, c + ORIGSLOT, c + RELOC);
    } else if ((first & 0x3B000000u) == 0x18000000u || (first & 0x7C000000u) == 0x14000000u || (first & 0x7E000000u) == 0x34000000u ||
               (first & 0x7E000000u) == 0x36000000u || (first & 0xFF000010u) == 0x54000000u) {
        err = "first instruction is pc-relative (b/bl/ldr lit/cbz): not relocatable";
        return false;
    }
    const uint32_t O = ORIGSLOT;
    w[0x00 / 4] = MRS_X9_CNTVCT;
    w[0x04 / 4] = ldr_x(10, c + 0x04, c + DEADLINE);
    w[0x08 / 4] = CMP_X9_X10;
    w[0x0C / 4] = b_hi(c + 0x0C, c + O);                       // deadline passed -> original path
    w[0x10 / 4] = ldr_w(11, c + 0x10, c + ENABLE);
    w[0x14 / 4] = cbz_w(11, c + 0x14, c + O);                  // disabled -> original path
    w[0x18 / 4] = ldr_s(3, c + 0x18, c + VALS + 0);
    w[0x1C / 4] = ldr_s(4, c + 0x1C, c + VALS + 4);
    w[0x20 / 4] = ldr_s(5, c + 0x20, c + VALS + 8);
    // store the new direction into the Ray the caller passed by reference (ptrReg): a write into ITS own memory, never into this r-x cave.
    w[0x24 / 4] = str_s(3, ptrReg, 12);
    w[0x28 / 4] = str_s(4, ptrReg, 16);
    w[0x2C / 4] = str_s(5, ptrReg, 20);
    w[0x30 / 4] = NOP; w[0x34 / 4] = NOP;
    w[O / 4] = origSlot;
    w[0x3C / 4] = b(c + 0x3C, func + 4);
    memcpy(&w[RELOC / 4], &reloc, 8);
    w[ORIGW / 4] = first;
    out.assign((uint8_t*)w, (uint8_t*)w + SIZE);
    return true;
}

bool RayHook::install(uint64_t func, std::string& err) {
    if (cave_) return true;
    uint32_t first = 0;
    if (!m_.read(func, &first, 4) || first == 0) { err = "function not readable"; return false; }
    if ((first & 0xFC000000u) == 0x14000000u) {
        uint64_t tgt = func + (uint64_t)(sext(first & 0x03FFFFFF, 26) << 2);
        if (is_cave_image(m_, tgt)) {
            uint32_t ow = 0;
            m_.read(tgt + ORIGW, &ow, 4);
            cp_.adopt(func, &ow, 4);
            cave_ = tgt; func_ = func;
            return true;
        }
        err = "function already starts with a branch (foreign patch?)";
        return false;
    }
    uint64_t c = find_cave(m_, func, err);
    if (!c) return false;
    std::vector<uint8_t> img;
    if (!build(c, func, first, /*x1*/ 1, img, err)) return false;
    if (!m_.write(c, img.data(), img.size())) { err = "cave write failed"; return false; }
    std::vector<uint8_t> back(img.size());
    if (!m_.read(c, back.data(), back.size()) || memcmp(back.data(), img.data(), img.size()) != 0) { err = "cave read-back mismatch"; return false; }
    uint32_t br = a64::b(func, c);
    if (!cp_.patch(func, &br, 4)) { err = "function patch failed"; return false; }
    cave_ = c; func_ = func;
    return true;
}

void RayHook::feed(Vec3 dir, uint64_t deadline) {
    if (!cave_) return;
    uint8_t blk[0x20] = {0};
    memcpy(blk, &deadline, 8);
    uint32_t en = 1;
    memcpy(blk + 8, &en, 4);
    float v[3] = {dir.x, dir.y, dir.z};
    memcpy(blk + 12, v, 12);
    m_.write(cave_ + DEADLINE, blk, sizeof blk);
    enabled_ = true;
}

void RayHook::off() {
    if (!cave_ || !enabled_) return;
    uint32_t z = 0;
    m_.write(cave_ + ENABLE, &z, 4);
    enabled_ = false;
}

void RayHook::uninstall() {
    off();
    if (func_) cp_.restore(func_);
    cave_ = 0; func_ = 0;
}
